(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const home=$('home'), cinema=$('cinematic'), gameView=$('game-view'), canvas=$('unity-canvas'), score=$('score');
  const realmNames={bamboo:['雾竹山谷','风穿竹海，雾落青山'],moon:['月下石庭','一庭月色，万籁微光'],altar:['浮空祭坛','越过云海，与天际共鸣']};
  let stage='bamboo', mode='ai', muted=true, engine=null, bootPromise=null, introTimer=null, textTimers=[], viewingOnly=false;
  let ready=false, introFinished=false, failed=false, reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
  const musicButton=$('music-toggle');
  score.volume=.5;
  function updateMusic() {
    musicButton.setAttribute('aria-pressed',String(!muted));
    musicButton.querySelector('span').textContent=muted?'音乐 · 关闭':'音乐 · 开启';
    if(muted || document.hidden || !gameView.hidden) score.pause();
    else score.play().catch(()=>{musicButton.querySelector('span').textContent='音乐 · 点击开启';});
  }
  function enableMusic(){muted=false;updateMusic();}
  musicButton.addEventListener('click',()=>{muted=!muted;updateMusic();if(engine&&!gameView.hidden)engine.SendMessage('Mist Echo Game','SetWebSound',muted?'off':'on');});
  $('start').addEventListener('click',()=>{enableMusic();$('selection').showModal();});
  $('controls-open').addEventListener('click',()=>$('controls').showModal());
  $('about-open').addEventListener('click',()=>$('about').showModal());
  document.querySelectorAll('[data-close]').forEach(button=>button.addEventListener('click',()=>$(button.dataset.close).close()));
  document.querySelectorAll('dialog').forEach(dialog=>dialog.addEventListener('click',event=>{if(event.target===dialog){const r=dialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)dialog.close();}}));
  document.querySelectorAll('[data-stage]').forEach(button=>button.addEventListener('click',()=>{
    stage=button.dataset.stage;
    document.querySelectorAll('[data-stage]').forEach(b=>{const selected=b===button;b.classList.toggle('selected',selected);b.setAttribute('aria-pressed',String(selected));});
    $('landscape').style.backgroundImage='url("Presentation/'+stage+'.png")';
    $('chapter-name').textContent=realmNames[stage][0];$('chapter-verse').textContent=realmNames[stage][1];
  }));
  document.querySelectorAll('[data-mode]').forEach(button=>button.addEventListener('click',()=>{
    mode=button.dataset.mode;
    document.querySelectorAll('[data-mode]').forEach(b=>{const selected=b===button;b.classList.toggle('selected',selected);b.setAttribute('aria-pressed',String(selected));});
  }));
  $('reduced-motion').checked=reduced;
  $('reduced-motion').addEventListener('change',event=>{reduced=event.target.checked;document.body.classList.toggle('reduce-motion',reduced);});
  document.body.classList.toggle('reduce-motion',reduced);
  const motes=document.querySelector('.motes');
  for(let i=0;i<22;i++){const mote=document.createElement('i');mote.className='mote';mote.style.left=(5+(i*37)%90)+'%';mote.style.top=(30+(i*17)%60)+'%';mote.style.animationDelay=-(i*.69)+'s';mote.style.animationDuration=(6+i%7)+'s';motes.append(mote);}

  function setProgress(value){$('load-progress').style.width=Math.round(Math.max(0,Math.min(1,value))*100)+'%';}
  function boot() {
    if(bootPromise)return bootPromise;
    failed=false;$('load-text').textContent='正在唤醒天地…';
    const config={...window.mistBuild,showBanner:(message,type)=>{
      if(type==='error')showFailure(message);
    }};
    bootPromise=createUnityInstance(canvas,config,p=>{
      setProgress(p);
      if(!introFinished)$('load-text').textContent='正在展开山海画卷 · '+Math.round(p*100)+'%';
    }).then(instance=>{
      engine=instance;ready=true;setProgress(1);syncEnter();return instance;
    }).catch(error=>{showFailure(error);return null;});
    return bootPromise;
  }
  function showFailure(error) {
    failed=true;$('load-text').textContent='画卷未能展开。请刷新重试，或换用支持 WebGL 2 的电脑浏览器。';
    $('cinema-home').hidden=false;$('cinema-home').textContent='返回首页';
    console.error('Mist Echo WebGL startup failed:',error);
  }
  function syncEnter() {
    if(failed)return;
    if(viewingOnly){$('load-text').textContent='三境之间，万象有声。';$('cinema-home').hidden=false;$('enter-arena').hidden=true;return;}
    if(!introFinished)return;
    $('enter-arena').hidden=false;$('enter-arena').disabled=!ready;
    $('enter-arena').textContent=ready?'进入战场 →':'载入中，请稍候…';
    $('load-text').textContent=ready?realmNames[stage][0]+' · 已准备就绪':'首次载入约 30 MB，请稍候…';
  }
  function clearIntroTimers(){if(introTimer)clearTimeout(introTimer);textTimers.forEach(clearTimeout);textTimers=[];introTimer=null;}
  function finishIntro() {
    clearIntroTimers();introFinished=true;cinema.classList.remove('playing');cinema.classList.add('finished');
    $('cinema-kicker').textContent='三境 · 共鸣';$('cinema-title').textContent='雾界回响';$('cinema-subtitle').textContent='一念起，山海应。';
    $('skip-intro').hidden=true;syncEnter();
  }
  function playIntro(only) {
    clearIntroTimers();viewingOnly=only;introFinished=false;home.hidden=true;cinema.hidden=false;gameView.hidden=true;
    cinema.className='cinematic';void cinema.offsetWidth;cinema.classList.add('playing');
    $('skip-intro').hidden=false;$('enter-arena').hidden=true;$('cinema-home').hidden=true;
    $('cinema-kicker').textContent='序 · 雾起';$('cinema-title').textContent='风起时，山海有了回声。';$('cinema-subtitle').textContent='雾竹山谷 · 风穿竹海';
    if(only){$('load-text').textContent='序章 · 山海有声';setProgress(1);}else{setProgress(ready?1:0);boot();}
    updateMusic();
    if(reduced){finishIntro();return;}
    textTimers.push(setTimeout(()=>{$('cinema-kicker').textContent='贰 · 月落';$('cinema-title').textContent='月落时，一念照见万象。';$('cinema-subtitle').textContent='月下石庭 · 万籁微光';},4800));
    textTimers.push(setTimeout(()=>{$('cinema-kicker').textContent='叁 · 问天';$('cinema-title').textContent='越过云海，与天地共鸣。';$('cinema-subtitle').textContent='浮空祭坛 · 天际回响';},9400));
    introTimer=setTimeout(finishIntro,14000);
  }
  $('journey').addEventListener('click',()=>{$('selection').close();enableMusic();playIntro(false);});
  $('watch-intro').addEventListener('click',()=>{enableMusic();playIntro(true);});
  $('skip-intro').addEventListener('click',finishIntro);
  $('enter-arena').addEventListener('click',()=>{
    if(!ready)return;score.pause();gameView.hidden=false;
    engine.SendMessage('Mist Echo Game','BeginFromWeb',JSON.stringify({stage,mode,muted}));
    cinema.hidden=true;home.hidden=true;canvas.focus();
  });
  function returnHome() {
    clearIntroTimers();if(engine)engine.SendMessage('Mist Echo Game','PauseFromWeb');
    cinema.hidden=true;gameView.hidden=true;home.hidden=false;updateMusic();$('start').focus();
  }
  $('cinema-home').addEventListener('click',returnHome);
  $('return-home').addEventListener('click',returnHome);
  $('fullscreen').addEventListener('click',async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await gameView.requestFullscreen();}catch{$('fullscreen').textContent='浏览器未支持全屏';}});
  document.addEventListener('fullscreenchange',()=>{$('fullscreen').textContent=document.fullscreenElement?'退出全屏':'全屏';});
  document.addEventListener('visibilitychange',()=>{if(document.hidden&&engine)engine.SendMessage('Mist Echo Game','PauseFromWeb');updateMusic();});
  canvas.addEventListener('pointerdown',()=>canvas.focus());
  window.addEventListener('keydown',event=>{if(!gameView.hidden&&['ArrowUp','ArrowDown','ArrowLeft','ArrowRight',' '].includes(event.key))event.preventDefault();});
})();
