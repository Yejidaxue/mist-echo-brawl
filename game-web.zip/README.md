# Mist Echo WebGL presentation

This is the source template for the public Unity WebGL player. The opening sequence uses three Gemini-generated backgrounds, timed crossfades, slow camera movement, intertitles, and the project's original synthesized music. It is a browser cinematic rather than a pre-rendered video.

The first click unlocks music. Unity loads during the opening; the final "进入战场" button is enabled only after the engine has initialized and sends the selected stage, mode, and sound preference into MistEchoGame.BeginFromWeb. The embedded Chinese font is a static subset of Noto Serif SC under SIL OFL.

Do not edit generated Build files. Change this template, then rebuild Unity.
